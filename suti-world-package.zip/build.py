#!/usr/bin/env python3
"""Build the standalone page from its shell, assets, and Markdown modules."""
from __future__ import annotations

import argparse
import html
import json
import re
import zipfile
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
BRANCHES = json.loads((ROOT / "source/branches.json").read_text(encoding="utf-8"))
GITHUB_REFERENCES = json.loads((ROOT / "source/github-public-links.json").read_text(encoding="utf-8"))
PUBLIC_GITHUB = {item["id"]: item for item in GITHUB_REFERENCES if item.get("status") == "public"}
LOCALES = json.loads((ROOT / "source/locales.json").read_text(encoding="utf-8"))
PRESERVED_INITIALS = {"AI", "LLM", "NLP", "UX", "SUTI", "SUTIcore", "Psychonetica", "Eidographica", "Syntaxium", "LinguaFUSION", "NITYA", "SUTI.OS", "SUTIspace", "Linguaetica", "Lingvetica", "VereNITYA", "SRETENIYA_OS", "YAZEKH", "SONOGENESIS", "Actica", "Fusion", "FUSION", "VereniumAI", "Lingvo", "Ezar", "Garuna", "Irkutsk", "Universidad", "Universidade", "Spanish", "English", "Portuguese", "Brazilian", "Telegram", "GitHub", "UNKNOWN", "FACT", "OBSERVATION", "INTERPRETATION", "HYPOTHESIS", "PASS", "PARTIAL", "FAIL", "HOLD", "TEST"}


def lower_public_style(value):
    pattern = re.compile(r"(^|[.!?:;]\s+|\n+)([«“\"'([{]?)([A-ZА-ЯЁ][\w’\-]*)", re.MULTILINE)

    def lower(match):
        token = match.group(3)
        if token in PRESERVED_INITIALS:
            return match.group(0)
        return match.group(1) + match.group(2) + token[0].lower() + token[1:]

    return pattern.sub(lower, value)


def display_copy(value):
    if isinstance(value, str):
        return lower_public_style(value)
    if isinstance(value, list):
        return [display_copy(item) for item in value]
    return value


def quick_ui(locale):
    labels = {
        "en": ("day", "night", "high contrast", "smaller text", "larger text", "display controls"),
        "es": ("día", "noche", "alto contraste", "texto menor", "texto mayor", "controles de pantalla"),
        "pt": ("dia", "noite", "alto contraste", "texto menor", "texto maior", "controles de exibição"),
        "ru": ("день", "ночь", "высокий контраст", "текст меньше", "текст больше", "настройки отображения"),
    }[locale]
    day, night, contrast, smaller, larger, group = labels
    return (
        f'<div class="quick-ui" role="group" aria-label="{html.escape(group)}">'
        f'<button type="button" data-quick-theme="light" aria-label="{html.escape(day)}" title="{html.escape(day)}">☼ <span>{html.escape(day)}</span></button>'
        f'<button type="button" data-quick-theme="dark" aria-label="{html.escape(night)}" title="{html.escape(night)}">◐ <span>{html.escape(night)}</span></button>'
        f'<button type="button" data-quick-contrast aria-pressed="false" aria-label="{html.escape(contrast)}" title="{html.escape(contrast)}">◩ <span>{html.escape(contrast)}</span></button>'
        f'<button type="button" data-quick-scale="down" aria-label="{html.escape(smaller)}" title="{html.escape(smaller)}">a−</button>'
        f'<button type="button" data-quick-scale="up" aria-label="{html.escape(larger)}" title="{html.escape(larger)}">a+</button>'
        '</div>'
    )


def language_switch(locale, in_subdir):
    routes = {"en": "../" if in_subdir else "./", "ru": "../ru/" if in_subdir else "ru/",
              "es": "../es/" if in_subdir else "es/", "pt": "../pt/" if in_subdir else "pt/"}
    labels = (("en", "en"), ("ru", "ru"), ("es", "es"), ("pt", "pt"))
    links = []
    for code, label in labels:
        current = ' aria-current="page"' if code == locale else ""
        links.append(f'<a lang="{code}" href="{routes[code]}"{current}>{label}</a>')
    group = {"en": "choose language", "es": "elige idioma", "pt": "escolha o idioma", "ru": "выбрать язык"}[locale]
    return f'<nav class="language-switch" aria-label="{group}">{"".join(links)}</nav>'


def locale_home(locale, css, copy, in_subdir):
    copy = {key: display_copy(value) for key, value in copy.items()}
    e = html.escape
    switch = language_switch(locale, in_subdir)
    toolbar = quick_ui(locale)
    thought_panel = f'''<aside class="thought-rotation" id="thought-rotation" aria-label="{e(copy["thought_label"])}"><span class="thought-glyph" aria-hidden="true">∴</span><div class="thought-copy"><p class="thought-label">{e(copy["thought_label"])}</p><p class="thought-text" id="thought-text" aria-live="polite">{e(copy["thoughts"][0])}</p><p class="thought-timing">{e(copy["thought_timing"])}</p></div><div class="thought-controls"><button type="button" id="thought-pause" aria-pressed="false">{e(copy["thought_pause"])}</button><button type="button" id="thought-next">{e(copy["thought_next"])}</button></div></aside>'''
    project_cycles = f'''<div class="method-lines"><p><b>{e(copy["cycle_title"])}</b><br>{e(copy["cycle_steps"])}</p><p><b>{e(copy["project_cycle_title"])}</b><br>{e(copy["project_cycle_steps"])}</p></div>'''
    card_specs = [
        ("clarity", "⧖", copy["clarity_title"], copy["clarity_text"], copy["clarity_example"],
         [("form_clarity_1", "situation", "form_clarity_1_ph", True), ("form_clarity_2", "question", "form_clarity_2_ph", True), ("form_clarity_3", "result", "form_clarity_3_ph", False)]),
        ("essence", "◉", copy["essence_title"], copy["essence_text"], copy["essence_example"],
         [("form_essence_2", "focus", "form_essence_2_ph", True), ("form_essence_3", "materials", "form_essence_3_ph", False)]),
        ("language", "⟁", copy["language_title"], copy["language_text"], copy["language_example"],
         [("form_language_1", "language", "form_language_1_ph", False), ("form_language_2", "situation", "form_language_2_ph", True), ("form_language_3", "goal", "form_language_3_ph", False)]),
    ]
    cards=[]
    for i,(key,mark,title,body,example,fields) in enumerate(card_specs):
        fields_html=[]
        if key=="essence":
            fields_html.append(f'<label>{e(copy["form_essence_1"])}<select name="subject"><option>{e(copy["form_essence_person"])}</option><option>{e(copy["form_essence_project"])}</option></select></label>')
        for label_key,name,placeholder_key,required in fields:
            attr=' required' if required else ''
            if name in ("situation","question","focus","materials","goal"):
                fields_html.append(f'<label>{e(copy[label_key])}<textarea name="{name}" maxlength="300" rows="2" placeholder="{e(copy[placeholder_key])}"{attr}></textarea></label>')
            else:
                fields_html.append(f'<label>{e(copy[label_key])}<input name="{name}" maxlength="100" placeholder="{e(copy[placeholder_key])}"{attr}></label>')
        detail_link = f'<p><a class="map-detail-link" href="essence/">{e(copy["map_detail_link"])}</a></p>' if key == "essence" else ""
        cards.append(f'''<article class="door" id="{key}-entry">
          <span class="door-mark" aria-hidden="true">{mark}</span><span class="door-title">{e(title)}</span>
          <p>{e(body)}</p><p class="work-example"><b>{e({"en":"example ::","es":"ejemplo ::","pt":"exemplo ::"}[locale])}</b> {e(example)}</p>{detail_link}
          <details class="intake"><summary>{e(copy["form_open"])}</summary>
            <form data-intake data-product="{e(title)}"><div class="field-stack">{"".join(fields_html)}</div>
              <button class="outline" type="submit">{e(copy["prepare"])}</button><p class="form-privacy">{e(copy["privacy"])}</p>
              <a class="telegram-draft solid" target="_blank" rel="noopener noreferrer" hidden>{e(copy["open_telegram"])}</a><p class="intake-status" role="status" aria-live="polite"></p>
            </form></details></article>''')
    prompt_specs=[("clarity_prompt_title","clarity_prompt_desc","clarity_prompt","clarity"),
                  ("system_prompt_title","system_prompt_desc","system_prompt","system"),
                  ("culture_prompt_title","culture_prompt_desc","culture_prompt","culture"),
                  ("essence_prompt_title","essence_prompt_desc","essence_prompt","essence"),
                  ("language_prompt_title","language_prompt_desc","language_prompt","language")]
    prompts=[]
    for title_k,desc_k,text_k,key in prompt_specs:
        prompts.append(f'''<details class="prompt-card"><summary>{e(copy[title_k])}</summary><p>{e(copy[desc_k])}</p>
          <textarea id="prompt-{key}" rows="8" readonly aria-label="{e(copy[title_k])}">{e(copy[text_k])}</textarea>
          <button type="button" data-copy="prompt-{key}">{e(copy["prompt_copy"])}</button><p class="copy-status" role="status" aria-live="polite"></p></details>''')
    root_href="../" if in_subdir else "./"
    html_page=f'''<!doctype html>
<html lang="{locale}" data-theme="dark" data-scale="1" data-contrast="normal">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#061d22"><meta name="description" content="{e(copy["description"])}"><title>{e(copy["title"])}</title><script>(function(){{var host=location.hostname.toLowerCase(),match=location.pathname.match(/[/](ru|es|pt)(?:[/]index[.]html)?[/]?$/);if((host==='suti.world'||host==='www.suti.world')&&match&&document.documentElement.lang!==match[1])location.replace('https://ezargaruna.github.io/suticore/'+match[1]+'/');}})();</script><style>{css}
.quick-ui{{display:flex;gap:4px;align-items:center;flex-wrap:wrap}}.quick-ui button{{min-height:44px;padding:7px 9px;font:12px var(--mono);white-space:nowrap}}.quick-ui button[aria-pressed="true"]{{background:var(--link);color:#fff;border-color:var(--link)}}.language-switch{{display:flex;align-items:center;gap:9px;padding:0 10px;border-inline:1px solid var(--line)}}.language-switch a{{font:12px var(--mono);text-transform:lowercase;text-decoration:none;padding:5px 2px}}.language-switch a[aria-current="page"]{{color:var(--ink);font-weight:700;border-bottom:2px solid var(--link)}}.locale-nav{{display:flex;align-items:center;gap:16px;margin-left:auto}}.locale-nav a{{font-size:13px;text-decoration:none}}.locale-hero{{max-width:1180px;margin:0 auto;padding:clamp(36px,8vw,82px) var(--gutter) 28px}}.locale-hero h1{{max-width:13ch;font-size:clamp(48px,8vw,92px)}}.locale-hero .hero-lead{{max-width:38ch;color:var(--muted)}}.locale-section{{max-width:1180px;margin:0 auto;padding:20px var(--gutter) 44px}}.locale-section>h2{{font-size:clamp(28px,4vw,42px)}}.locale-cards{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}}.locale-cards .door{{min-height:260px}}.door-mark{{color:var(--link);width:40px;height:40px;border:1px solid var(--link);border-radius:50%;display:grid;place-items:center}}.door .work-example{{font-size:13px}}.field-stack{{display:grid;gap:9px}}.about-card{{max-width:820px;padding:clamp(20px,4vw,36px);background:var(--surface);border:1px solid var(--line);border-radius:18px}}.about-card p{{max-width:70ch}}.education-note{{color:var(--muted);font-size:14px}}.locale-crystal{{max-width:1180px;margin:0 auto 36px;padding:0 var(--gutter)}}.locale-crystal>details{{border:1px solid var(--line);border-radius:18px;background:var(--surface)}}.locale-crystal summary{{cursor:pointer}}.locale-crystal>details>summary{{padding:18px 20px}}.crystal-copy{{padding:0 20px 20px}}.prompt-kit{{display:grid;gap:10px}}.prompt-card textarea{{min-height:160px}}.library-note{{padding:14px 0;border-top:1px solid var(--line)}}.locale-footer{{border-top:1px solid var(--line);margin-top:32px;padding:20px var(--gutter);text-align:center;color:var(--muted)}}
.symbol-thread{{display:flex;align-items:center;gap:12px;margin:20px 0 0;padding:12px 0;border-block:1px solid var(--line);font:12px var(--mono);color:var(--support)}}.symbol-thread span:first-child{{color:var(--link);font-size:15px;letter-spacing:.06em}}
.method-lines{{margin:18px 0;padding:14px 16px;border-left:3px solid var(--link);border-radius:0 14px 14px 0;background:var(--sky)}}.method-lines p{{margin:6px 0;max-width:90ch}}.method-lines b{{font:12px var(--mono);color:var(--muted)}}
@media(max-width:1020px){{.topbar{{flex-wrap:wrap;gap:10px 14px}}.locale-nav{{order:4;width:100%;margin:0;flex-wrap:wrap}}.quick-ui{{margin-left:auto}}.language-switch{{margin-left:auto}}}}
@media(max-width:700px){{.locale-cards{{grid-template-columns:1fr}}.locale-cards .door{{min-height:0}}.locale-nav{{order:5}}.language-switch{{margin-left:0}}.quick-ui{{margin-left:auto}}.locale-hero h1{{font-size:clamp(42px,12vw,66px)}}}}
html[data-contrast="high"],body[data-contrast="high"]{{--bg:#fff;--surface:#fff;--ink:#111;--muted:#222;--link:#064a44;--support:#173f3a;--line:#333;--warm:#71311d;--focus:#111}}
html[data-theme="dark"][data-contrast="high"],body[data-theme="dark"][data-contrast="high"]{{--bg:#000;--surface:#080a08;--ink:#fff;--muted:#fff;--link:#9cf5e6;--support:#e1fff8;--line:#fff;--warm:#ffc09e;--focus:#fff}}
body[data-scale="0.9"]{{--body:16.2px}}body[data-scale="1.1"]{{--body:19.8px}}body[data-scale="1.25"]{{--body:22.5px}}body[data-scale="1.4"]{{--body:25.2px}}
</style></head>
<body><a class="skip" href="#main">{e(copy["skip"])}</a>
<header class="topbar" id="top"><a class="wordmark" href="{root_href}"><span aria-hidden="true">∴</span> SUTI.world</a>
<nav class="locale-nav" aria-label="{e(copy["cards_title"])}"><a href="#clarity-entry">{e(copy["clarity_title"])}</a><a href="#essence-entry">{e(copy["essence_title"])}</a><a href="#language-entry">{e(copy["language_title"])}</a><a href="#about">{e(copy["nav_about"])}</a><a href="#contact">{e(copy["nav_contact"])}</a></nav>
{switch}{toolbar}</header>
<main id="main"><section class="locale-hero"><p class="eyebrow">{e(copy["hero_kicker"])}</p><h1>{e(copy["hero_title"])}</h1><p class="hero-lead">{e(copy["hero_lead"])}</p><p>{e(copy["hero_pick"])}</p></section>
<section class="locale-section" aria-labelledby="entries-title"><h2 id="entries-title">{e(copy["cards_title"])}</h2><div class="locale-cards">{"".join(cards)}</div><p class="symbol-thread"><span aria-hidden="true">⧖ ━ ◉ ━ ⟁</span><span>{e(copy["glyph_thread"])}</span></p></section>
{thought_panel}
<section class="locale-section" id="about" aria-labelledby="about-title"><div class="about-card"><p class="eyebrow">{e(copy["about_label"])}</p><h2 id="about-title">{e(copy["about_title"])}</h2><p>{e(copy["about_text"])}</p><p class="education-note">{e(copy["education"])}</p></div></section>
<section class="locale-crystal" aria-label="{e(copy["crystal_title"])}"><details><summary><span class="eyebrow">{e(copy["crystal_label"])}</span><strong>{e(copy["crystal_title"])}</strong></summary><div class="crystal-copy">
<p>{e(copy["crystal_clarity"])}</p><p>{e(copy["crystal_distinction"])}</p><p>{e(copy["crystal_essence"])}</p>{project_cycles}<p class="small-status">{e(copy["crystal_status"])}</p>
<details class="prompt-kit"><summary>{e(copy["prompt_kit"])}</summary>{"".join(prompts)}</details></div></details></section>
<section class="locale-section library-note" id="contact"><p>{e(copy["library_note"])} <a href="{root_href}ru/#world">{e(copy["library_link"])}</a></p><p><a href="https://t.me/saritamah">{e(copy["contact_link"])}</a></p></section></main>
<footer class="locale-footer"><p>SUTI.world · Ezar Garuna</p><p>{e(copy["footer_note"])}</p></footer>
<script>
(function(){{var locale={json.dumps(locale)},thoughts={json.dumps(copy['thoughts'],ensure_ascii=False)};document.querySelectorAll('form[data-intake]').forEach(function(form){{form.addEventListener('submit',function(event){{event.preventDefault();var lines=['SUTI.world :: '+form.dataset.product];Array.prototype.forEach.call(form.elements,function(field){{if(field.name&&String(field.value||'').trim())lines.push(field.name+' :: '+String(field.value).trim());}});var link=form.querySelector('.telegram-draft'),status=form.querySelector('.intake-status'),draft=new URL('https://t.me/saritamah');draft.searchParams.set('text',lines.join('\\n'));link.href=draft.href;link.hidden=false;status.textContent={json.dumps(copy['draft_ready'],ensure_ascii=False)};link.focus();}});}});
document.querySelectorAll('[data-copy]').forEach(function(button){{button.addEventListener('click',function(){{var field=document.getElementById(button.dataset.copy),status=button.nextElementSibling;if(!field)return;field.focus();field.select();var done=function(ok){{status.textContent=ok?{json.dumps(copy['copy_success'],ensure_ascii=False)}:{json.dumps(copy['copy_manual'],ensure_ascii=False)};}};if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(field.value).then(function(){{done(true);}},function(){{done(document.execCommand('copy'));}});else done(document.execCommand('copy'));}});}});
(function(){{var host=document.getElementById('thought-rotation'),text=document.getElementById('thought-text'),pause=document.getElementById('thought-pause'),next=document.getElementById('thought-next'),index=0,last=0,stopped=window.matchMedia('(prefers-reduced-motion: reduce)').matches,timer;function advance(){{var n=Math.floor(Math.random()*(thoughts.length-1));if(n>=last)n++;last=n;index=n;text.textContent=thoughts[index];text.classList.remove('thought-enter');void text.offsetWidth;text.classList.add('thought-enter');schedule();}}function schedule(){{clearTimeout(timer);if(host&&!stopped&&!document.hidden)timer=setTimeout(advance,36000);}}if(host&&text&&pause&&next){{pause.addEventListener('click',function(){{stopped=!stopped;pause.textContent=stopped?{json.dumps(copy['thought_resume'],ensure_ascii=False)}:{json.dumps(copy['thought_pause'],ensure_ascii=False)};pause.setAttribute('aria-pressed',String(stopped));schedule();}});next.addEventListener('click',advance);document.addEventListener('visibilitychange',schedule);schedule();}}}})();
var store='suti-world-view-v2',contrastStore='suti-world-contrast-v1',state={{theme:'dark',scale:'1',contrast:'normal'}};try{{var saved=JSON.parse(localStorage.getItem(store)||'{{}}');state.theme=saved.theme==='light'?'light':'dark';state.scale=saved.scale||'1';state.contrast=localStorage.getItem(contrastStore)||'normal';}}catch(e){{}}function apply(){{var root=document.documentElement,body=document.body;root.dataset.theme=body.dataset.theme=state.theme;root.dataset.scale=body.dataset.scale=state.scale;root.dataset.contrast=body.dataset.contrast=state.contrast;var meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.content=state.theme==='dark'?'#061d22':'#F5F1E8';document.querySelectorAll('[data-quick-theme]').forEach(function(b){{b.setAttribute('aria-pressed',String(b.dataset.quickTheme===state.theme));}});document.querySelectorAll('[data-quick-contrast]').forEach(function(b){{b.setAttribute('aria-pressed',String(state.contrast==='high'));}});try{{var saved=JSON.parse(localStorage.getItem(store)||'{{}}');saved.theme=state.theme;saved.scale=state.scale;localStorage.setItem(store,JSON.stringify(saved));localStorage.setItem(contrastStore,state.contrast);}}catch(e){{}}}}document.querySelectorAll('[data-quick-theme]').forEach(function(b){{b.addEventListener('click',function(){{state.theme=b.dataset.quickTheme;apply();}});}});document.querySelectorAll('[data-quick-contrast]').forEach(function(b){{b.addEventListener('click',function(){{state.contrast=state.contrast==='high'?'normal':'high';apply();}});}});document.querySelectorAll('[data-quick-scale]').forEach(function(b){{b.addEventListener('click',function(){{var values=['0.9','1','1.1','1.25','1.4'],i=values.indexOf(String(state.scale));if(i<0)i=1;state.scale=values[Math.max(0,Math.min(values.length-1,i+(b.dataset.quickScale==='up'?1:-1)))];apply();}});}});apply();}})();
</script></body></html>'''
    return "\n".join(line.rstrip(" \t") for line in html_page.splitlines()) + "\n"


def read_modules():
    result = []
    for path in sorted((ROOT / "modules").glob("*.md")):
        text = path.read_text(encoding="utf-8")
        if not text.startswith("---\n"):
            raise ValueError(f"frontmatter missing: {path.name}")
        _, front, body = text.split("---\n", 2)
        meta = {}
        for line in front.splitlines():
            if ":" in line:
                key, value = line.split(":", 1)
                meta[key.strip()] = value.strip()
        required = ("id", "title", "branch", "type", "status", "topics", "author")
        missing = [key for key in required if not meta.get(key)]
        if missing:
            raise ValueError(f"{path.name}: missing {', '.join(missing)}")
        meta["branches"] = [part.strip() for part in meta["branch"].split(",")]
        meta["github_refs"] = [part.strip() for part in meta.get("github", "").split(",") if part.strip()]
        unknown_refs = set(meta["github_refs"]) - set(PUBLIC_GITHUB)
        if unknown_refs:
            raise ValueError(f"{path.name}: unknown or non-public GitHub references {sorted(unknown_refs)}")
        meta["source"] = "modules/" + path.name
        body = lower_public_style(body.strip())
        meta["markdown"] = body
        meta["plain"] = re.sub(r"[`*_#>-]", " ", body)
        meta["html"] = markdown_html(body)
        result.append(meta)
    ids = [item["id"] for item in result]
    if len(ids) != len(set(ids)):
        raise ValueError("module IDs must be unique")
    known = {branch["id"] for branch in BRANCHES}
    for item in result:
        unknown = set(item["branches"]) - known
        if unknown:
            raise ValueError(f"{item['id']}: unknown branches {sorted(unknown)}")
    return result


def markdown_html(text):
    output = []
    list_kind = None
    paragraph = []

    def close_blocks():
        nonlocal list_kind, paragraph
        if paragraph:
            output.append("<p>" + " ".join(paragraph) + "</p>")
            paragraph = []
        if list_kind:
            output.append(f"</{list_kind}>")
            list_kind = None

    for line in text.splitlines():
        value = line.strip()
        if not value:
            close_blocks()
            continue
        heading = re.match(r"^(#{2,4})\s+(.+)$", value)
        if heading:
            close_blocks()
            level = len(heading.group(1))
            output.append(f"<h{level}>{inline(heading.group(2))}</h{level}>")
            continue
        bullet = re.match(r"^(?:[-*]|\d+\.)\s+(.+)$", value)
        if bullet:
            if paragraph:
                close_blocks()
            kind = "ol" if re.match(r"^\d+\.", value) else "ul"
            if list_kind != kind:
                close_blocks()
                output.append(f"<{kind}>")
                list_kind = kind
            output.append("<li>" + inline(bullet.group(1)) + "</li>")
            continue
        if list_kind:
            close_blocks()
        paragraph.append(inline(value))
    close_blocks()
    return "\n".join(output)


def inline(text):
    safe = html.escape(text, quote=False)
    safe = re.sub(r"`([^`]+)`", r"<code>\1</code>", safe)
    safe = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", safe)
    return safe


def make_branches(modules):
    public = [item for item in modules if item["status"] == "available"]
    chunks = []
    for branch in BRANCHES:
        branch_id, title, invite = branch["id"], branch["title"], branch["invite"]
        assigned = [item for item in public if branch_id in item["branches"]]
        cards = []
        for item in assigned:
            canonical = item["branches"][0]
            if canonical != branch_id:
                cards.append(
                    f'<p class="material-ref" data-material="{html.escape(item["id"])}" '
                    f'data-branches="{html.escape(",".join(item["branches"]))}">'
                    f'<a href="#m-{html.escape(item["id"])}">{html.escape(item["title"])} · открыть материал</a></p>'
                )
                continue
            search = " ".join((item["title"], item["topics"], item["author"], item["plain"], " ".join(item["branches"])))
            github_links = ""
            if item["github_refs"]:
                links = "".join(
                    '<li><a href="' + html.escape(PUBLIC_GITHUB[ref]["url"], quote=True)
                    + '" target="_blank" rel="noopener noreferrer">'
                    + html.escape(PUBLIC_GITHUB[ref]["title"]) + ' ↗</a></li>'
                    for ref in item["github_refs"]
                )
                github_links = '<div class="github-links"><p>проверенные файлы</p><ul>' + links + '</ul></div>'
            cards.append(
                f'<details class="material" id="m-{html.escape(item["id"])}" '
                f'data-id="{html.escape(item["id"])}" data-type="{html.escape(item["type"])}" '
                f'data-branches="{html.escape(",".join(item["branches"]))}" '
                f'data-search="{html.escape(search, quote=True)}">'
                f'<summary><span class="material-title">{html.escape(item["title"])}</span>'
                f'<span class="material-meta">{html.escape(item["type"])} · {html.escape(item["author"])}</span></summary>'
                f'<article class="material-body">{item["html"]}{github_links}'
                f'<p class="material-source">источник: {html.escape(item["source"])} · статус: доступно</p>'
                f'<button class="back-list" type="button">назад к списку</button></article></details>'
            )
        if branch_id == "game":
            cards.append('<p class="branch-empty">игра готовится · доступных испытаний пока нет</p>')
        if branch_id == "language":
            cards.append('<div class="branch-entry"><p>узнай, как двигаться дальше в языке.</p><button class="outline" type="button" data-form="language">найти свою языковую волну</button></div>')
        if not assigned and branch_id != "game":
            cards.append('<p class="branch-empty">материалы готовятся</p>')
        chunks.append(
            f'<details class="branch" id="b-{branch_id}" data-branch="{branch_id}">'
            f'<summary><span class="branch-name">{html.escape(title)}</span>'
            f'<span class="branch-invite">{html.escape(invite)}</span></summary>'
            f'<div class="branch-content">{"".join(cards)}</div></details>'
        )
    return "\n".join(chunks)


def vault_example(locale):
    copy = {
      "ru": ("SUTI.OS в Obsidian", "рабочий пример · структура ещё уточняется", "один вопрос → связанная запись → действие → след", ["вход", "ядро", "язык", "игра", "содружество", "исследование", "шаблоны", "промпты"], "как работать", ["запиши один вопрос", "отдели известное от предположений", "свяжи запись с картой проекта", "выбери шаг и проверь результат"], "системные правила и форматы обмена", "это обезличенный пример, а не доступ к личному хранилищу"),
      "en": ("SUTI.OS in Obsidian", "working example · structure under development", "one question → linked note → action → trace", ["entry", "core", "language", "game", "community", "research", "templates", "prompts"], "how to work", ["write one question", "separate what is known from assumptions", "link the note to a project map", "choose a step and check its result"], "system rules and exchange formats", "an anonymous example, not access to a personal vault"),
      "es": ("SUTI.OS en Obsidian", "ejemplo de trabajo · estructura en desarrollo", "una pregunta → nota enlazada → acción → registro", ["entrada", "núcleo", "lenguaje", "juego", "comunidad", "investigación", "plantillas", "prompts"], "cómo trabajar", ["escribe una pregunta", "separa lo conocido de las suposiciones", "enlaza la nota con un mapa del proyecto", "elige un paso y comprueba el resultado"], "reglas del sistema y formatos de intercambio", "ejemplo anónimo, sin acceso a un archivo personal"),
      "pt": ("SUTI.OS no Obsidian", "exemplo de trabalho · estrutura em desenvolvimento", "uma pergunta → nota vinculada → ação → registro", ["entrada", "núcleo", "linguagem", "jogo", "comunidade", "pesquisa", "modelos", "prompts"], "como trabalhar", ["escreva uma pergunta", "separe o conhecido das suposições", "vincule a nota a um mapa do projeto", "escolha um passo e confira o resultado"], "regras do sistema e formatos de intercâmbio", "exemplo anônimo, sem acesso a um arquivo pessoal"),
    }
    title,status,lead,folders,how,steps,system,note=copy[locale]
    tree="".join(f'<li><span>{i:02d}</span>{html.escape(name)}</li>' for i,name in enumerate(folders))
    instructions="".join(f'<li>{html.escape(step)}</li>' for step in steps)
    example=html.escape(json.dumps({"id":"example", "status":"proposed", "purpose":steps[0], "source":"example", "related":["project-map"], "next_step":steps[3], "result":"unknown"},ensure_ascii=False,indent=2))
    return f'<section class="vault-example section-wrap" id="suti-os" aria-labelledby="vault-title"><p class="eyebrow">{html.escape(status)}</p><h2 id="vault-title">{html.escape(title)}</h2><p>{html.escape(lead)}</p><details class="vault-expand"><summary>{html.escape(how)}</summary><div class="vault-layout"><ul class="vault-tree">{tree}<li><span>_system</span>{html.escape(system)}</li></ul><div class="vault-data"><h3>{html.escape(how)}</h3><ol>{instructions}</ol><details><summary>Markdown + JSON</summary><pre>{example}</pre></details></div></div></details><p class="vault-note">{html.escape(note)}</p></section>'


def visual_route(locale):
    labels = {
        "ru": ("от вопроса к действию", ["вопрос", "различение", "выбор", "действие"]),
        "en": ("from question to action", ["question", "distinction", "choice", "action"]),
        "es": ("de la pregunta a la acción", ["pregunta", "distinción", "elección", "acción"]),
        "pt": ("da pergunta à ação", ["pergunta", "distinção", "escolha", "ação"]),
    }
    title, steps = labels[locale]
    drawings = [
        '<circle cx="32" cy="32" r="20"/><path d="M26 25a6 6 0 0 1 12 0c0 5-6 5-6 10"/><path d="M32 42h.01"/>',
        '<path d="M14 18h36M14 32h14m8 0h14M14 46h36M32 12v40"/>',
        '<path d="M32 52V34L16 18m16 16 16-16M16 28V18h10m12 0h10v10"/>',
        '<circle cx="32" cy="32" r="20"/><path d="m21 32 8 8 15-17"/>',
    ]
    cards = "".join(f'<li><svg viewBox="0 0 64 64" aria-hidden="true">{drawing}</svg><span class="route-number">0{i+1}</span><span>{html.escape(label)}</span></li>' for i,(label,drawing) in enumerate(zip(steps,drawings)))
    return f'<figure class="visual-route section-wrap"><figcaption>{html.escape(title)}</figcaption><ol>{cards}</ol></figure>'


def modes_section(locale):
    copy = {
        "ru": ("четыре режима работы", "метафора получает смысл через функцию и проверку", [("∴", "земля · опора", "SUTIcore хранит определения, источники и решения", "проверка :: источник · версия · целостность"), ("≈", "вода · понимание", "synaura различает ситуацию, важное и ограничения", "проверка :: человек подтверждает понимание"), ("≋", "воздух · маршрут", "Syntaxium помогает выбрать подходящий инструмент", "проверка :: результат или ясная причина остановки"), ("△", "огонь · действие", "разрешённый инструмент выполняет выбранную операцию", "проверка :: выход соответствует задаче")]),
        "en": ("four modes of work", "the metaphor earns its place through function and a check", [("∴", "earth · support", "SUTIcore keeps definitions, sources and decisions", "check :: source · version · integrity"), ("≈", "water · understanding", "synaura distinguishes the situation, priorities and limits", "check :: the person confirms understanding"), ("≋", "air · route", "Syntaxium helps choose a suitable tool", "check :: result or a clear reason to stop"), ("△", "fire · action", "an allowed tool performs the chosen operation", "check :: output fits the task")]),
        "es": ("cuatro modos de trabajo", "la metáfora se sostiene con una función y una comprobación", [("∴", "tierra · apoyo", "SUTIcore conserva definiciones, fuentes y decisiones", "comprobación :: fuente · versión · integridad"), ("≈", "agua · comprensión", "synaura distingue la situación, lo importante y los límites", "comprobación :: la persona confirma que fue comprendida"), ("≋", "aire · ruta", "Syntaxium ayuda a elegir una herramienta adecuada", "comprobación :: resultado o motivo claro para detenerse"), ("△", "fuego · acción", "una herramienta permitida realiza la operación elegida", "comprobación :: el resultado corresponde a la tarea")]),
        "pt": ("quatro modos de trabalho", "a metáfora faz sentido quando traz função e verificação", [("∴", "terra · apoio", "SUTIcore guarda definições, fontes e decisões", "verificação :: fonte · versão · integridade"), ("≈", "água · compreensão", "synaura distingue a situação, o que importa e os limites", "verificação :: a pessoa confirma que foi compreendida"), ("≋", "ar · rota", "Syntaxium ajuda a escolher uma ferramenta adequada", "verificação :: resultado ou motivo claro para parar"), ("△", "fogo · ação", "uma ferramenta permitida executa a operação escolhida", "verificação :: o resultado corresponde à tarefa")])
    }[locale]
    title, lead, rows = copy
    cards = "".join(f'<article class="mode-card"><span aria-hidden="true">{symbol}</span><h3>{name}</h3><p>{function}</p><small>{check}</small></article>' for symbol,name,function,check in rows)
    return vault_example(locale) + visual_route(locale) + f'<section class="modes section-wrap" aria-labelledby="modes-title"><p class="eyebrow">synaura × Syntaxium</p><h2 id="modes-title">{title}</h2><p>{lead}</p><div class="modes-grid">{cards}</div></section>'


def local_font_css(prefix):
    css = (ROOT / "assets/fonts/fonts.css").read_text(encoding="utf-8")
    return css.replace('url("', 'url("' + prefix)


def build():
    modules = read_modules()
    public = [item for item in modules if item["status"] == "available"]
    data = [{key: item[key] for key in ("id", "title", "branches", "type", "status", "topics", "author", "source", "markdown", "plain", "github_refs")} for item in public]
    data_json = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c").replace("&", "\\u0026")
    shell = (ROOT / "source/index-shell.html").read_text(encoding="utf-8")
    css = (ROOT / "source/site.css").read_text(encoding="utf-8")
    js = (ROOT / "source/site.js").read_text(encoding="utf-8")
    html_page = shell.replace("__CSS__", css).replace("__JS__", js).replace("__DATA__", data_json)
    html_page = html_page.replace("</style>", local_font_css("../assets/fonts/") + "</style>", 1)
    html_page = html_page.replace('<aside class="thought-rotation"', modes_section("ru") + '<aside class="thought-rotation"', 1)
    branch_json = json.dumps(BRANCHES, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    html_page = html_page.replace("__BRANCHES__", make_branches(modules)).replace("__BRANCHES_DATA__", branch_json)
    select_options = "".join(f'<option value="{html.escape(item["id"])}">{html.escape(item["title"])}</option>' for item in public)
    html_page = html_page.replace("__MATERIAL_OPTIONS__", select_options)
    html_page = html_page.replace("__LANGUAGE_SWITCH__", language_switch("ru", True)).replace("__QUICK_UI__", quick_ui("ru"))
    if "__" in html_page:
        raise ValueError("unexpanded build placeholder")
    html_page = "\n".join(line.rstrip(" \t") for line in html_page.splitlines()) + "\n"
    russian_output = ROOT / "ru/index.html"
    russian_output.parent.mkdir(parents=True, exist_ok=True)
    russian_output.write_text(html_page, encoding="utf-8")
    if russian_output.stat().st_size > 1_000_000:
        raise ValueError("page exceeds 1 MB budget")
    css = "\n".join(line.rstrip(" \t") for line in css.splitlines()) + "\n"
    output = ROOT / "index.html"
    output.write_text(locale_home("en", css, LOCALES["en"], False).replace("</style>", local_font_css("assets/fonts/") + "</style>", 1).replace('<aside class="thought-rotation"', modes_section("en") + '<aside class="thought-rotation"', 1), encoding="utf-8")
    for locale in ("es", "pt"):
        target = ROOT / locale / "index.html"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(locale_home(locale, css, LOCALES[locale], True).replace("</style>", local_font_css("../assets/fonts/") + "</style>", 1).replace('<aside class="thought-rotation"', modes_section(locale) + '<aside class="thought-rotation"', 1), encoding="utf-8")
    # Detailed, directly addressable essence-map page in all public locales.
    from source.essence_page import render as render_essence
    for locale in ("en", "ru", "es", "pt"):
        target = ROOT / locale / "essence/index.html" if locale != "en" else ROOT / "essence/index.html"
        target.parent.mkdir(parents=True, exist_ok=True)
        prefix = "../../assets/fonts/" if locale != "en" else "../assets/fonts/"
        essence_html = render_essence(locale).replace("</style>", css + local_font_css(prefix) + "</style>", 1)
        target.write_text(essence_html, encoding="utf-8")
    for target in (output, ROOT / "es/index.html", ROOT / "pt/index.html"):
        if target.stat().st_size > 1_000_000:
            raise ValueError(f"localized page exceeds 1 MB budget: {target.relative_to(ROOT)}")
    config = re.search(r'var CONFIG=\{clarityUrl:"([^"\\]*)",languageUrl:"([^"\\]*)",contactUrl:"([^"\\]*)"\}', js)
    if not config:
        raise ValueError("clarityUrl and languageUrl must be configured in one place")
    allowed_urls = [value for value in config.groups() if value]
    allowed_urls.extend(item["url"] for item in PUBLIC_GITHUB.values())
    allowed_urls.append("https://ezargaruna.github.io/suticore/")
    for value in allowed_urls:
        parsed = urlparse(value)
        if parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password:
            raise ValueError("form links must be valid HTTPS addresses")
    for item in PUBLIC_GITHUB.values():
        if urlparse(item["url"]).netloc != "github.com" or not item["url"].startswith("https://github.com/ezargaruna/suticore/blob/main/"):
            raise ValueError(f"GitHub link is outside the reviewed repository: {item['id']}")
    found_urls = re.findall(r"https?://[^\s\"'<>]+", html_page)
    if any(value not in allowed_urls for value in found_urls):
        raise ValueError("unexpected external URL in standalone page")
    localized_targets = {"en": output, "es": ROOT / "es/index.html", "pt": ROOT / "pt/index.html"}
    for locale, localized_path in localized_targets.items():
        translated = localized_path.read_text(encoding="utf-8")
        if f'<html lang="{locale}"' not in translated or 'href="https://t.me/saritamah"' not in translated:
            raise ValueError(f"localized page metadata/contact missing: {locale}")
        if translated.count('class="door"') != 3 or translated.count('class="prompt-card"') != 5 or translated.count("data-intake data-product=") != 3:
            raise ValueError(f"localized page sections incomplete: {locale}")
        if translated.count("data-quick-theme=") != 2 or translated.count("data-quick-contrast") < 1 or translated.count("data-quick-scale=") != 2:
            raise ValueError(f"quick display controls missing: {locale}")
        for code in ("en", "ru", "es", "pt"):
            if f'<a lang="{code}"' not in translated:
                raise ValueError(f"language selector incomplete: {locale} -> {code}")
        education_tokens = {"en": "Irkutsk State Linguistic University", "es": "Universidad Estatal Lingüística de Irkutsk", "pt": "Universidade Estatal Linguística de Irkutsk"}
        if education_tokens[locale] not in translated or "2013" not in translated or "linguist-translator" not in translated and locale == "en":
            raise ValueError(f"author education copy missing: {locale}")
        if "Мир Света" in translated or "/Users/saritamah" in translated:
            raise ValueError(f"private material in localized page: {locale}")
        if translated.count('class="thought-rotation"') != 1 or translated.count('id="thought-pause"') != 1 or translated.count('id="thought-next"') != 1:
            raise ValueError(f"thought controls missing or duplicated: {locale}")
        if LOCALES[locale].get("thoughts") and any(phrase not in translated for phrase in LOCALES[locale]["thoughts"]):
            raise ValueError(f"thought text missing: {locale}")
    output_urls = re.findall(r"https?://[^\s\"'<>]+", output.read_text(encoding="utf-8"))
    if any(value not in allowed_urls for value in output_urls):
        raise ValueError("unexpected external URL in English home")
    price_pattern = re.compile(r"(?:\$\s?[\d,]|€\s?\d|₽\s?\d|\d[\d\s,.]*\s?(?:USDT|USD|EUR|RUB|руб\.?|R\$))", re.IGNORECASE)
    for public_path in (russian_output, output, ROOT / "es/index.html", ROOT / "pt/index.html"):
        public_html = public_path.read_text(encoding="utf-8")
        if price_pattern.search(public_html):
            raise ValueError(f"price data must not enter public output: {public_path.relative_to(ROOT)}")
        if "fonts.googleapis.com" in public_html or "fonts.gstatic.com" in public_html:
            raise ValueError(f"external font request remains: {public_path.relative_to(ROOT)}")
        if "Noto Sans SC" not in public_html or "Noto Sans Arabic" not in public_html or "Noto Sans Devanagari" not in public_html:
            raise ValueError(f"script fallback missing: {public_path.relative_to(ROOT)}")
        if "Мир Света" in public_html or "/Users/saritamah" in public_html:
            raise ValueError(f"private content in public output: {public_path.relative_to(ROOT)}")
    return output, modules


def make_zip():
    target = ROOT / "suti-world-package.zip"
    files = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path == target or "__pycache__" in path.parts:
            continue
        if "modules" in path.parts:
            text = path.read_text(encoding="utf-8")
            match = re.search(r"^status:\s*(\S+)", text, re.M)
            if not match or match.group(1) != "available":
                continue
        if path.name == "viewport-probe.html":
            continue
        files.append(path)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            archive.write(path, path.relative_to(ROOT))
    return target


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="build and verify the standalone page")
    args = parser.parse_args()
    page, modules = build()
    package = make_zip()
    print(f"page: {page.name} · {page.stat().st_size} bytes")
    print(f"modules: {len(modules)} · public: {sum(m['status'] == 'available' for m in modules)} · draft: {sum(m['status'] != 'available' for m in modules)}")
    print(f"package: {package.name} · {package.stat().st_size} bytes")
    if args.check:
        with zipfile.ZipFile(package) as archive:
            bad = archive.testzip()
            if bad:
                raise SystemExit(f"zip integrity failure: {bad}")
        print("check: PASS")


if __name__ == "__main__":
    main()
