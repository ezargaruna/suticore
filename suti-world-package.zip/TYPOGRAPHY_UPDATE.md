# SUTI.world typography update

- Status: implemented locally; publishing not performed.
- Source revision: Google Fonts commit `9710da1eacb3be272583c3224dcb70f9da6eadbb`.
- Families: Literata 3.103, Onest 2.001, Noto Sans SC 2.004-H2, Noto Sans Arabic 2.012, Noto Sans Devanagari 2.007, Noto Sans Symbols 2 2.008, IBM Plex Mono 2.3.
- Exact upstream asset URLs, variable axes, source hashes, and generated WOFF2 hashes: `assets/fonts/sources.json`. OFL license copies sit in each family directory.
- The homepage uses Literata for headings and Onest for interface/body text. Mixed-script fields include Noto fallback families; `unicode-bidi: plaintext` follows the entered script direction. RTL page direction is configured for `lang=ar`. Noto Sans SC is split into Unicode-range WOFF2 subsets so unused glyph ranges are not requested.
- Rare SUTI operators absent from the selected symbol font fall back to system symbol fonts.
- A localized four-mode section (earth, water, air, fire) joins the supplied design direction to the existing homepage in en/ru/es/pt. It states functions and checks without presenting the metaphor as a technical mechanism.
- The existing selectable interface languages are en/ru/es/pt. Chinese, Arabic, Esperanto, Latin, and Sanskrit do not yet have translated interface versions in this build; their local font fallbacks are available for text content/input, but visual QA on full localized pages remains open.
- Validation: `python3 build.py --check` PASS; all five script samples are present in their respective Noto families; all nine SUTI operators are present in IBM Plex Mono or use the documented system-symbol fallback; local WOFF2 request returned HTTP 200; generated page contains no Google Fonts host references. The standalone package ZIP passed integrity validation.
- Browser visual inspection was limited: the available Chrome view applied a dark/high-contrast state and then changed application state during a theme interaction. A clean light-theme comparison, mobile layout, and 200% zoom remain unverified.

## Rollback

Restore the pre-change copy at `/Users/saritamah/_audit/suti-typography-20261003/before` to the project directory. The copy was verified against a SHA-256 manifest at `before-manifest.json` (40/40 source files matched before migration). Alternatively, revert the changes in `source/site.css`, `build.py`, and `README.md`, remove `TYPOGRAPHY_UPDATE.md` and `assets/fonts/`, then rerun `python3 build.py --check` to regenerate the original pages and ZIP.


## Preference update · 2026-10-03

The current readability preference supersedes the earlier serif-heading pairing:
Literata is retained in the licensed local asset set for provenance, but is no
longer used by this site. Onest is now the sans-serif family for headings,
interface, and body text at regular readable weights; IBM Plex Mono remains
limited to technical labels and code. The site CSS source is authoritative;
localized pages and the package are regenerated from it.

This is a local style update only. Publication was not performed.
